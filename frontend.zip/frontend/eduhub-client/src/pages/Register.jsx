// src/pages/Register.jsx
import React, { useState } from "react";
import { registerUser } from "../api/auth";

export default function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleRegister(e) {
    e.preventDefault();
    setBusy(true);

    const res = await registerUser(name, email, password);

    if (res.ok) {
      alert("Registered — please login.");
      window.location.href = "/login";
    } else {
      alert(res.data.msg || "Register failed");
    }

    setBusy(false);
  }

  return (
    <div className="max-w-md mx-auto mt-20 p-6 shadow bg-white rounded-xl">
      <h2 className="text-2xl font-bold mb-4">Register</h2>

      <form onSubmit={handleRegister}>
        <input
          className="w-full p-2 mb-3 border rounded"
          placeholder="Your Name"
          onChange={(e) => setName(e.target.value)}
        />

        <input
          className="w-full p-2 mb-3 border rounded"
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          className="w-full p-2 mb-3 border rounded"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          disabled={busy}
          className="w-full bg-blue-600 text-white py-2 rounded-lg"
        >
          {busy ? "Registering..." : "Register"}
        </button>
      </form>
    </div>
  );
}
