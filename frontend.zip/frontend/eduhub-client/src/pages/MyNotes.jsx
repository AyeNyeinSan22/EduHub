import { useEffect, useState } from "react";
import {Link, useNavigate } from "react-router-dom";
import axios from "axios";
import NotesCard from "../components/NotesCard";
import DeleteModal from "../components/DeleteModal";

export default function MyNotes() {
  const [notes, setNotes] = useState([]);
  const navigate = useNavigate();

  const [deleteId, setDeleteId] = useState(null);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  useEffect(() => {
    axios.get("http://127.0.0.1:5000/api/notes").then(res => {
      setNotes(res.data);
    });
  }, []);

  const handleDelete = async (id) => {
    setDeleteId(id);
    setConfirmDeleteOpen(true);
  };
  
const confirmDelete = async () => {
  try {
    await axios.delete(`http://127.0.0.1:5000/api/notes/${deleteId}`);
    setNotes(prev => prev.filter(n => n.id !== deleteId));
  } catch (err) {
    console.error("Delete failed:", err);
  }
  setConfirmDeleteOpen(false);
};

  
  return (
    <div>

      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">Your Shelf</h1>

        <Link
          to="/notes/new"
          className="bg-orange-500 text-white px-4 py-2 rounded-full font-semibold flex items-center gap-2"
        >
          ➕ New
        </Link>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-10 mb-6 text-gray-600">
        <span className="font-semibold text-orange-600">All Books</span>
        <span>Favourite</span>
        <span>E-Books</span>
        <span>Audio Books</span>
        <span>Articles & Journals</span>
      </div>
     
     <DeleteModal
      open={confirmDeleteOpen}
      onClose={() => setConfirmDeleteOpen(false)}
      onConfirm={confirmDelete}
     />

      {/* Notes Grid */}
      <div className="grid grid-cols-4 gap-6">

        {notes.map(note => (
          <NotesCard
              key={note.id}
              note={note}
              onRead={() => navigate(`/notes/read/${note.id}`)}
              onEdit={() => navigate(`/notes/edit/${note.id}`)}
              onDelete={() => handleDelete(note.id)}
  />
        ))}

      </div>
    </div>
  );
}
