import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";

/**
 * Profile.jsx
 * - GET /api/auth/me (requires Authorization header)
 * - Allows updating local profile fields (UI only)
 * - Includes "Create Note" form posting to POST /api/notes as multipart/form-data
 * - Requires JWT token in localStorage "eduhub_token"
 */

export default function Profile() {
  const navigate = useNavigate();
  const [user, setUser] = useState(null);
  const [loadingUser, setLoadingUser] = useState(true);
  const [error, setError] = useState("");

  // create note state
  const [title, setTitle] = useState("");
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState("");
  const [notesText, setNotesText] = useState("");
  const [file, setFile] = useState(null);
  const [cover, setCover] = useState(null);
  const [creating, setCreating] = useState(false);
  const [notesList, setNotesList] = useState([]);

  // auth helper
  const token = localStorage.getItem("eduhub_token");
  const authHeader = token ? { Authorization: `Bearer ${token}` } : {};

  useEffect(() => {
    if (!token) {
      navigate("/auth/login");
      return;
    }
    (async () => {
      setLoadingUser(true);
      try {
        const res = await axios.get("http://127.0.0.1:5000/api/auth/me", { headers: authHeader });
        setUser(res.data);
      } catch (err) {
        console.error("Failed to get profile", err);
        // token invalid? force logout
        localStorage.removeItem("eduhub_token");
        localStorage.removeItem("eduhub_user");
        navigate("/auth/login");
      } finally {
        setLoadingUser(false);
      }
    })();

    // load notes list (optional)
    loadNotes();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadNotes() {
    try {
      const res = await axios.get("http://127.0.0.1:5000/api/notes", { headers: authHeader });
      setNotesList(res.data || []);
    } catch (e) {
      setNotesList([]);
    }
  }

  async function handleCreateNote(e) {
    e.preventDefault();
    setError("");
    if (!title || !subject || !category) {
      setError("Title, subject and category are required.");
      return;
    }
    setCreating(true);
    try {
      const form = new FormData();
      form.append("title", title);
      form.append("subject", subject);
      form.append("category", category);
      form.append("notes", notesText || "");
      if (file) form.append("file", file);
      if (cover) form.append("cover", cover);

      const res = await axios.post("http://127.0.0.1:5000/api/notes", form, {
        headers: { ...authHeader, "Content-Type": "multipart/form-data" }
      });
      // success — reset form & reload notes
      setTitle(""); setSubject(""); setCategory(""); setNotesText(""); setFile(null); setCover(null);
      await loadNotes();
      alert("Note created");
    } catch (err) {
      console.error("Create note error", err);
      setError(err.response?.data?.error || "Failed to create note.");
    } finally {
      setCreating(false);
    }
  }

  function logout() {
    localStorage.removeItem("eduhub_token");
    localStorage.removeItem("eduhub_user");
    navigate("/auth/login");
  }

  if (loadingUser) {
    return <div style={{padding:40}}>Loading profile…</div>;
  }

  return (
    <div style={{minHeight:"100vh", padding:24, background:"#f6f8fb", boxSizing:"border-box", fontFamily:"Inter, system-ui"}}>
      <div style={{maxWidth:1100, margin:"0 auto", display:"flex", gap:20}}>
        {/* left column: profile + create note */}
        <div style={{flex:"0 0 360px"}}>
          <div style={{background:"#fff", borderRadius:12, padding:18, boxShadow:"0 10px 40px rgba(2,6,23,0.06)"}}>
            <div style={{display:"flex", gap:12, alignItems:"center"}}>
              <div style={{width:76,height:76,borderRadius:999,background:"#f3f4f6",display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700}}>
                {user?.name ? user.name.split(" ").map(s=>s[0]).slice(0,2).join("") : "U"}
              </div>
              <div>
                <div style={{fontWeight:800}}>{user?.name || "User"}</div>
                <div style={{color:"#6b7280", fontSize:13}}>{user?.email}</div>
              </div>
            </div>

            <hr style={{margin:"12px 0"}} />
            <div style={{display:"flex",gap:8}}>
              <button onClick={()=>alert("Upload photo placeholder")} style={{padding:8,borderRadius:8,background:"#eef2ff"}}>Upload Photo</button>
              <button onClick={logout} style={{padding:8,borderRadius:8,background:"#fee2e2",color:"#ef4444"}}>Logout</button>
            </div>
          </div>

          {/* Create Note card */}
          <div style={{background:"#fff",borderRadius:12,padding:16,marginTop:14,boxShadow:"0 10px 40px rgba(2,6,23,0.06)"}}>
            <h3 style={{margin:0}}>Create Note</h3>
            <form onSubmit={handleCreateNote} style={{display:"flex",flexDirection:"column",gap:10,marginTop:12}}>
              <input placeholder="Title" value={title} onChange={e=>setTitle(e.target.value)} style={{padding:10,borderRadius:8,border:"1px solid rgba(16,24,40,0.06)"}} />
              <input placeholder="Subject" value={subject} onChange={e=>setSubject(e.target.value)} style={{padding:10,borderRadius:8,border:"1px solid rgba(16,24,40,0.06)"}} />
              <input placeholder="Category" value={category} onChange={e=>setCategory(e.target.value)} style={{padding:10,borderRadius:8,border:"1px solid rgba(16,24,40,0.06)"}} />
              <textarea placeholder="Short notes" value={notesText} onChange={e=>setNotesText(e.target.value)} style={{minHeight:80,padding:10,borderRadius:8,border:"1px solid rgba(16,24,40,0.06)"}} />

              <label style={{fontSize:13}}>PDF File (optional)</label>
              <input type="file" accept=".pdf" onChange={(e)=>setFile(e.target.files[0] || null)} />

              <label style={{fontSize:13}}>Cover Image (optional)</label>
              <input type="file" accept="image/*" onChange={(e)=>setCover(e.target.files[0] || null)} />

              {error && <div style={{color:"#ef4444"}}>{error}</div>}

              <div style={{display:"flex",gap:8,justifyContent:"flex-end"}}>
                <button type="button" onClick={()=>{ setTitle(""); setSubject(""); setCategory(""); setNotesText(""); setFile(null); setCover(null); }} style={{padding:10,borderRadius:8}}>Reset</button>
                <button type="submit" disabled={creating} style={{padding:10,borderRadius:8,background:"#fb923c",color:"#fff",border:"none",fontWeight:700}}>
                  {creating ? "Creating..." : "Create Note"}
                </button>
              </div>
            </form>
          </div>
        </div>

        {/* right column: notes list (and extra profile details) */}
        <div style={{flex:1}}>
          <div style={{background:"#fff",borderRadius:12,padding:18,boxShadow:"0 10px 40px rgba(2,6,23,0.06)"}}>
            <h3 style={{margin:0}}>Profile</h3>
            <div style={{marginTop:10,color:"#6b7280"}}>Joined: {user?.created_at || "N/A"}</div>
            <div style={{marginTop:6,color:"#6b7280"}}>Notes count: {notesList.length}</div>
          </div>

          <div style={{marginTop:14}}>
            <h3 style={{marginBottom:8}}>My Notes</h3>
            <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:12}}>
              {notesList.length ? notesList.map(n=>(
                <div key={n.id} style={{background:"#fff",borderRadius:12,padding:12,boxShadow:"0 10px 30px rgba(2,6,23,0.04)"}}>
                  <div style={{fontWeight:800}}>{n.title}</div>
                  <div style={{color:"#6b7280",fontSize:13}}>{n.subject} • {n.category}</div>
                  <div style={{marginTop:8,display:"flex",gap:8,justifyContent:"flex-end"}}>
                    <a href={n.file_url} target="_blank" rel="noreferrer"><button style={{padding:6,borderRadius:8}}>Open</button></a>
                    <button onClick={()=>alert("Edit placeholder")} style={{padding:6,borderRadius:8}}>Edit</button>
                  </div>
                </div>
              )) : <div style={{color:"#9ca3af"}}>No notes yet</div>}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
