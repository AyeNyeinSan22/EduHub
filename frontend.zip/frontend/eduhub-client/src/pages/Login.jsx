// src/pages/Login.jsx
import React, { useState } from "react";
import { loginUser } from "../api/auth";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function handleLogin(e) {
    e.preventDefault();
    setBusy(true);

    const res = await loginUser(email, password);

    if (res.ok) {
      window.location.href = "/notes"; // redirect
    } else {
      alert(res.msg);
    }

    setBusy(false);
  }

  return (
    <div className="max-w-md mx-auto mt-20 p-6 shadow bg-white rounded-xl">
      <h2 className="text-2xl font-bold mb-4">Login</h2>

      <form onSubmit={handleLogin}>
        <input
          className="w-full p-2 mb-3 border rounded"
          placeholder="Email"
          onChange={(e) => setEmail(e.target.value)}
        />

        <input
          type="password"
          className="w-full p-2 mb-3 border rounded"
          placeholder="Password"
          onChange={(e) => setPassword(e.target.value)}
        />

        <button
          disabled={busy}
          className="w-full bg-orange-500 text-white py-2 rounded-lg"
        >
          {busy ? "Checking..." : "Login"}
        </button>
      </form>
    </div>
  );
}
