// // // src/api/notes.js
// // import axios from "axios";

// // const BASE_URL = import.meta.env.VITE_API_URL || "http://127.0.0.1:5000";
// // const client = axios.create({ baseURL: BASE_URL });

// // export async function createNote(formData, onUploadProgress) {
// //   const res = await client.post("/api/notes", formData, {
// //     headers: { "Content-Type": "multipart/form-data" },
// //     onUploadProgress,
// //   });
// //   return res.data;
// // }

// // export async function listNotes() {
// //   const res = await client.get("/api/notes");
// //   return res.data;
// // }

// // export async function updateNote(id, formData) {
// //   const res = await client.put(`/api/notes/${id}`, formData, {
// //     headers: { "Content-Type": "multipart/form-data" },
// //   });
// //   return res.data;
// // }

// // export async function deleteNote(id) {
// //   const res = await client.delete(`/api/notes/${id}`);
// //   return res.data;
// // }
// // src/api/notes.js
// import { apiRequest, apiForm } from "./client";

// // GET all notes for logged-in user
// export function fetchNotes() {
//   return apiRequest("/api/notes");
// }

// // GET single note
// export function fetchNote(id) {
//   return apiRequest(`/api/notes/${id}`);
// }

// // DELETE note
// export function deleteNote(id) {
//   return apiRequest(`/api/notes/${id}`, "DELETE");
// }

// // CREATE note with FormData
// export function createNote({ subject, title, category, notes, file, cover }) {
//   const fd = new FormData();
//   fd.append("subject", subject);
//   fd.append("title", title);
//   fd.append("category", category);
//   fd.append("notes", notes || "");

//   if (file) fd.append("file", file);
//   if (cover) fd.append("cover", cover);

//   return apiForm("/api/notes", fd);
// }

// // UPDATE note with FormData
// export function updateNote(id, { subject, title, category, notes, file, cover }) {
//   const fd = new FormData();
//   if (subject) fd.append("subject", subject);
//   if (title) fd.append("title", title);
//   if (category) fd.append("category", category);
//   if (notes) fd.append("notes", notes);
//   if (file) fd.append("file", file);
//   if (cover) fd.append("cover", cover);

//   return apiForm(`/api/notes/${id}`, fd);
// }

// /* ---------------------------
//    BOOKMARKS API
// ---------------------------- */
// export function getBookmarks(noteId) {
//   return apiRequest(`/api/notes/${noteId}/bookmarks`);
// }

// export function addBookmark(noteId, page, title = null) {
//   return apiRequest(`/api/notes/${noteId}/bookmarks`, "POST", {
//     page,
//     title,
//   });
// }

// export function deleteBookmark(noteId, bookmarkId) {
//   return apiRequest(`/api/notes/${noteId}/bookmarks`, "DELETE", {
//     id: bookmarkId,
//   });
// }

// /* ---------------------------
//    ANNOTATIONS API
// ---------------------------- */

// export function getAnnotations(noteId) {
//   return apiRequest(`/api/notes/${noteId}/annotations`);
// }

// export function addAnnotation(noteId, page, x_pct, y_pct, text) {
//   return apiRequest(`/api/notes/${noteId}/annotations`, "POST", {
//     page,
//     x_pct,
//     y_pct,
//     text,
//   });
// }

// export function deleteAnnotation(noteId, id) {
//   return apiRequest(`/api/notes/${noteId}/annotations`, "DELETE", {
//     id,
//   });
// }

// /* ---------------------------
//    LAST PAGE SAVE
// ---------------------------- */

// export function getLastPage(noteId) {
//   return apiRequest(`/api/notes/${noteId}/lastpage`);
// }

// export function saveLastPage(noteId, page) {
//   return apiRequest(`/api/notes/${noteId}/lastpage`, "POST", { page });
// }
// src/api/notes.js
// src/api/notes.js
import { apiRequest } from "./client";

// GET all notes
export async function getNotes() {
  return apiRequest("/api/notes", "GET");
}

// GET single note
export async function getNote(id) {
  return apiRequest(`/api/notes/${id}`, "GET");
}

// CREATE note (FormData)
export async function createNote(formData) {
  return apiRequest("/api/notes", "POST", formData, true);
}

// UPDATE note (FormData)
export async function updateNote(id, formData) {
  return apiRequest(`/api/notes/${id}`, "PUT", formData, true);
}

// DELETE note
export async function deleteNote(id) {
  return apiRequest(`/api/notes/${id}`, "DELETE");
}

// GET bookmarks
export async function getBookmarks(id) {
  return apiRequest(`/api/notes/${id}/bookmarks`, "GET");
}

// ADD bookmark
export async function addBookmark(id, page, title) {
  return apiRequest(`/api/notes/${id}/bookmarks`, "POST", {
    page,
    title,
  });
}

// UPDATE bookmark
export async function updateBookmark(id, bookmarkId, title) {
  return apiRequest(`/api/notes/${id}/bookmarks`, "PUT", {
    id: bookmarkId,
    title,
  });
}

// DELETE bookmark
export async function deleteBookmark(id, bookmarkId) {
  return apiRequest(`/api/notes/${id}/bookmarks`, "DELETE", {
    id: bookmarkId,
  });
}

// GET annotations
export async function getAnnotations(id) {
  return apiRequest(`/api/notes/${id}/annotations`, "GET");
}

// ADD annotation
export async function addAnnotation(id, payload) {
  return apiRequest(`/api/notes/${id}/annotations`, "POST", payload);
}

// UPDATE annotation
export async function updateAnnotation(id, payload) {
  return apiRequest(`/api/notes/${id}/annotations`, "PUT", payload);
}

// DELETE annotation
export async function deleteAnnotation(id, annotationId) {
  return apiRequest(`/api/notes/${id}/annotations`, "DELETE", {
    id: annotationId,
  });
}

// GET last read page
export async function getLastPage(id) {
  return apiRequest(`/api/notes/${id}/lastpage`, "GET");
}

// SAVE last read page
export async function saveLastPage(id, page) {
  return apiRequest(`/api/notes/${id}/lastpage`, "POST", { page });
}
