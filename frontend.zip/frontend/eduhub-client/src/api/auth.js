// src/api/auth.js
import { apiJSON } from "./client";

export async function loginUser(email, password) {
  const res = await apiJSON("/api/auth/login", "POST", { email, password });
  const data = await res.json();

  if (res.ok && data.token) {
    localStorage.setItem("token", data.token);
    return { ok: true, token: data.token };
  }

  return { ok: false, msg: data.msg || "Login failed" };
}

export async function registerUser(name, email, password) {
  const res = await apiJSON("/api/auth/register", "POST", {
    name,
    email,
    password,
  });

  const data = await res.json();
  return { ok: res.ok, data };
}

export function logoutUser() {
  localStorage.removeItem("token");
  localStorage.removeItem("user");
}
